package Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entities.Tasks;

public class TaskDao {

	private Connection conn;

	public TaskDao(Connection conn) {
		super();
		this.conn = conn;
	}

	public boolean addTask(String name, String task, String status) {
		boolean flag = false;
		try {
			String query = "insert into task_details(name,task,status) values(?,?,?)";
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, name);
			ps.setString(2, task);
			ps.setString(3, status);
			int temp = ps.executeUpdate();
			if (temp == 1) {
				flag = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return flag;
	}

	public List<Tasks> getTasks() {
		List<Tasks> tasks_list = new ArrayList<Tasks>();
		Tasks task = null;
		try {
			String query1 = "select * from task_details";
			PreparedStatement ps1 = conn.prepareStatement(query1);
			ResultSet rs = ps1.executeQuery();
			while (rs.next()) {
				task = new Tasks();
				task.setId(rs.getInt(1));
				task.setName(rs.getString(2));
				task.setTask(rs.getString(3));
				task.setStatus(rs.getString(4));
				tasks_list.add(task);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tasks_list;
	}

	public Tasks getTasksById(int id) {
		Tasks t = null;
		try {
			String query2 = "select * from task_details where id=?";
			PreparedStatement ps2 = conn.prepareStatement(query2);
			ps2.setInt(1, id);
			ResultSet rs1 = ps2.executeQuery();
			while (rs1.next()) {
				t = new Tasks();
				t.setId(rs1.getInt(1));
				t.setName(rs1.getString(2));
				t.setTask(rs1.getString(3));
				t.setStatus(rs1.getString(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t;
	}

	public boolean UpdateTask(Tasks t) {
		boolean flag = false;
		try {
			String query3 = "update task_details set name=?,task=?,status=? where id=?";
			PreparedStatement ps3 = conn.prepareStatement(query3);
			ps3.setString(1, t.getName());
			ps3.setString(2, t.getTask());
			ps3.setString(3, t.getStatus());
			ps3.setInt(4, t.getId());
			int temp = ps3.executeUpdate();
			if (temp == 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean DeleteTask(int id) {
		boolean flag = false;
		try {
			String query4 = "delete from task_details where id=?";
			PreparedStatement ps4 = conn.prepareStatement(query4);
			ps4.setInt(1, id);
			int temp = ps4.executeUpdate();
			if (temp == 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
