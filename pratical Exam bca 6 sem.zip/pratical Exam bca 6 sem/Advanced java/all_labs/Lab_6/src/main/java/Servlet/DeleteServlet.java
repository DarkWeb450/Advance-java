package Servlet;
import java.io.IOException;
import Dao.TaskDao;
import Database.Dbconnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/delete")
public class DeleteServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		TaskDao dao = new TaskDao(Dbconnection.getConn());
		boolean flag = dao.DeleteTask(id);
		HttpSession session = req.getSession();
		if (flag) {
			session.setAttribute("Successmsg", "Task deleted successfully!!!!");
			resp.sendRedirect("index.jsp");
		} else {
			session.setAttribute("errorsmsg", "Oops, something went wrong!!!!");
			resp.sendRedirect("index.jsp");

		}

	}

}
