package Servlet;
import java.io.IOException;
import Dao.TaskDao;
import Database.Dbconnection;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/add")
public class AddServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String username = req.getParameter("username");
		String task = req.getParameter("taskname");
		String status = req.getParameter("status");
		TaskDao dao = new TaskDao(Dbconnection.getConn());
		boolean flag = dao.addTask(username, task, status);
		HttpSession session = req.getSession();
		if (flag) {
			session.setAttribute("Successmsg", "Task added successfully!!!!");
			resp.sendRedirect("index.jsp");
		} else {
			session.setAttribute("errorsmsg", "Oops, something went wrong!!!!");
			resp.sendRedirect("index.jsp");
		}

	}

}
