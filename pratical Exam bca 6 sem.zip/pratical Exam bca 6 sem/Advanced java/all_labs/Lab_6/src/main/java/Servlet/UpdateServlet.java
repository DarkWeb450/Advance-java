package Servlet;
import java.io.IOException;
import Dao.TaskDao;
import Database.Dbconnection;
import entities.Tasks;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/update")
public class UpdateServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String username = req.getParameter("username");
		String task = req.getParameter("taskname");
		String status = req.getParameter("status");
		TaskDao dao = new TaskDao(Dbconnection.getConn());
		Tasks t = new Tasks();
		t.setId(id);
		t.setName(username);
		t.setTask(task);
		t.setStatus(status);
		boolean flag = dao.UpdateTask(t);
		HttpSession session = req.getSession();
		if (flag) {
			session.setAttribute("Successmsg", "Task updated successfully!!!!");
			resp.sendRedirect("index.jsp");
		} else {
			session.setAttribute("errorsmsg", "Oops, something went wrong!!!!");
			resp.sendRedirect("index.jsp");

		}
	}

}
