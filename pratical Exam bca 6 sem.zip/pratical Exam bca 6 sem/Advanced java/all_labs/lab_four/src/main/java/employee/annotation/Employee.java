package employee.annotation;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "emp_details")
public class Employee {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int e_id;
private String e_name;
private double e_sal;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(int e_id, String e_name, double e_sal) {
	super();
	this.e_id = e_id;
	this.e_name = e_name;
	this.e_sal = e_sal;
}
public int getE_id() {
	return e_id;
}
public void setE_id(int e_id) {
	this.e_id = e_id;
}
public String getE_name() {
	return e_name;
}
public void setE_name(String e_name) {
	this.e_name = e_name;
}
public double getE_sal() {
	return e_sal;
}
public void setE_sal(double e_sal) {
	this.e_sal = e_sal;
}

}
