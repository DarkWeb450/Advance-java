<?php  
function reverseNumber($num)
{
$revnum = 0; 
while ($num > 1)  
{  
$rem = $num % 10;  
$revnum = ($revnum * 10) + $rem;  
$num = ($num / 10);   
}  
return $revnum;
}
function sumOfDigits($num) 
{
$numStr = (string)$num; 
$sum = 0;
for ($i = 0; $i < strlen($numStr); $i++)
{ 
        $sum += $numStr[$i]; 
} 
return $sum; 
} 
$num = 123456;
$reversed = reverseNumber($num);
$sum = sumOfDigits($num);
echo "Original Number : $num<br><br>";
echo "Reversed Number : $reversed<br><br>";
echo "Sum of Digits : $sum<br><br>";
?>  