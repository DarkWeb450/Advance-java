<?php
$avatars = array(
    "Vamana" => 5,
    "Parashurama" => 6,
    "Rama" => 7,
    "Matsya" => 1,
    "Kurma" => 2,
    "Varaha" => 3,
    "Narasimha" => 4,
    "Krishna" => 8,
    "Buddha" => 9,
    "Kalki" => 10
);
asort($avatars);
echo "Avatars of Lord Vishnu sorted in ascending order by value :<br><br>";
foreach ($avatars as $avatar => $value) 
{
 echo "$avatar : $value<br><br>";
}
?>
