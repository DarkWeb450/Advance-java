<?php
//Addition function
function add($a, $b) 
{
    return $a + $b;
}
//Subtraction function
function subtract($a, $b) 
{
    return $a - $b;
}
//Multiplication function
function multiply($a, $b) 
{
    return $a * $b;
}
//Division function
function divide($a, $b) 
{
    if ($b == 0) {
        return "Error: Division by zero";
    }
    return $a / $b;
}
//Exponential function
function power($base, $exponent) 
{
    return pow($base, $exponent);
}
//Absolute value function
function absolute($number) 
{
    return abs($number);
}
//Square root function
function squareRoot($number) 
{
    if ($number < 0) 
    {
        return "Error: Cannot calculate square root of a negative number";
    }
    return sqrt($number);
}
// Testing the functions
$a = 12;
$b = 7;
echo "Addition: " . add($a, $b) . "<br>";
echo "Subtraction: " . subtract($a, $b) . "<br>";
echo "Multiplication: " . multiply($a, $b) . "<br>";
echo "Division: " . divide($a, $b) . "<br>";
echo "Exponential: " . power($a, $b) . "<br>";
echo "Absolute value of -10: " . absolute(-10) . "<br>";
echo "Square root of 25: " . squareRoot(25) . "<br>";
?>
