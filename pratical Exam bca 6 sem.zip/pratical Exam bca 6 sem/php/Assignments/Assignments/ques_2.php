<?php
// Global variable
$globalSentence = "Aryan Amar is a good boy";
// Function to show global scope
function showGlobalScope() 
{
    global $globalSentence;
    echo "Global Scope: $globalSentence <br>";
}
// Function to show static scope
function showStaticScope() 
{
    static $staticSentence = "Aryan Amar is a good boy";
    echo "Static Scope: $staticSentence <br>";
    $staticSentence = "Static scope is different now";
}
// Function to show local scope
function showLocalScope() 
{
    $localSentence = "Aryan Amar is a good boy";
    echo "Local Scope: $localSentence <br>";
}
// Calling each function
showGlobalScope();
showStaticScope();
showLocalScope();
// Showing that static scope persists between function calls
showStaticScope();
?>
