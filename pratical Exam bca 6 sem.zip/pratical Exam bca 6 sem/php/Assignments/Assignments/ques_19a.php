<?php
include 'include_example.php';
// This line will execute even if "include_example.php" is not found
echo "<br>This is a lab file of PHP created by Aryan Amar";
?>
