<?php 
function check_Prime($n) 
{ 
if ($n == 1 || $n == 0) 
{ 
  return false; 
} 
for ($i = 2; $i <= sqrt($n); $i++) 
{ 
if ($n % $i == 0) 
{ 
  return false; 
} 
} 
  return true; 
} 
echo "The first 20 prime numbers are as follows :<br>";
$primeCount = 0;
$num = 2;
while ($primeCount < 20)
{
if (check_Prime($num))
{
echo "$num<br>";
$primeCount++;
}
$num++;
}
?>