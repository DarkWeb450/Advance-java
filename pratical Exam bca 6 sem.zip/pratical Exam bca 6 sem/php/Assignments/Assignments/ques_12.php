<?php
$avatars = array(
    "Rudra" => 11,
    "Ardhanarishvara" => 12,
    "Pashupati" => 13,
    "Nataraja" => 14,
    "Bhairava" => 15,
    "Mrityunjaya" => 16,
    "Kala Bhairava" => 17,
    "Dakshinamurthy" => 18,
    "Tripurantaka" => 19,
    "Virabhadra" => 20
);
krsort($avatars);
echo "Avatars of Lord Shiva sorted in descending order by key :<br><br>";
foreach ($avatars as $avatar => $value) {
    echo "$avatar : $value<br><br>";
}
?>
