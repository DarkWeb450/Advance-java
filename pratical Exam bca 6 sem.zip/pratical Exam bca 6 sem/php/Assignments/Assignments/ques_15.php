<?php

// Variables to be compacted
$name = "Aryan Amar";
$age = 21;
$city = "Arrah";

//Compacting the variables into an array
$compactArray = compact("name", "age", "city");

// Displaying the compacted array
echo "Array obtained from compact() function :<br><br>";
print_r($compactArray);
echo "<br><br><br>";

// Creating an array containing variables
$extractArray = array(
    "name" => "Swami Vivekananda",
    "age" => 38,
    "city" => "West Bengal"
);

// Extracting the variables from the array into the local symbol table
extract($extractArray);

// Displaying the extracted variables
echo "Variables obtained from extract() function :<br><br>";
echo "Name: $name<br><br>";
echo "Age: $age<br><br>";
echo "City: $city<br><br>";

?>
