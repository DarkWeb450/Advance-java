<?php
$filename = "example2.txt";
$file = fopen($filename, "r");
if ($file) 
{
 while (($line = fgets($file)) !== false) 
 {
  echo "<h3>" . $line . "</h3><br>";
 }
 fclose($file);
} 
else 
{
 echo "Error: Unable to open file.";
}
?>
