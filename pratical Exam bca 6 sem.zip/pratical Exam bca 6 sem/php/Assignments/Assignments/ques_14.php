<?php
// Input string
$inputString = "my,name,is,Aryan,Amar";
// Exploding the input string into an array
$arrayFromExplode = explode(",", $inputString);
// Displaying the array obtained from explode() function
echo "Array obtained from explode() :<br><br>";
print_r($arrayFromExplode);
echo "<br><br><br>";
// Joining the array elements into a string using implode() function
$stringFromImplode = implode("-", $arrayFromExplode);
// Displaying the string obtained from implode() function
echo "String obtained from implode() :<br><br>";
echo $stringFromImplode;
?>
