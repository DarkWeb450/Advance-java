<!DOCTYPE html>
<html>
<head>
    <title>Age Verification</title>
</head>
<body>
    <h2>Age Verification</h2>
    <form method="post">
        Enter your age: <input type="text" name="age"><br><br>
        <input type="submit" name="submit" value="Check Eligibility">
    </form>
    <?php
    class AgeException extends Exception 
    {
     public function errorMessage() 
     {
      return '<br>Error : ' . $this->getMessage();
     }
    }
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
     try 
     {
      $age = $_POST['age'];
      if ($age === '' || !is_numeric($age)) 
      {
       throw new AgeException('Invalid input. Please enter a valid age.');
      }
      if ($age < 18) 
      {
       throw new AgeException('You are not allowed to vote. You must be at least 18 years old.');
      } 
      else 
      {
       echo "<br>You are eligible for voting.";
      }
     } 
     catch (AgeException $e) 
     {
      echo $e->errorMessage();
     }
    }
    ?>
</body>
</html>
