<?php
function addMatrices($matrix1, $matrix2) 
{
    $rows = count($matrix1);
    $cols = count($matrix1[0]);
    $result = array();
for ($i = 0; $i < $rows; $i++) 
{
    for ($j = 0; $j < $cols; $j++) 
    {
      $result[$i][$j] = $matrix1[$i][$j] + $matrix2[$i][$j];
    }
}
return $result;
}
function displayMatrix($matrix) 
{
  foreach ($matrix as $row) 
  {
   foreach ($row as $cell) 
   {
    echo $cell . "\t";
   }
   echo "<br>";
  }
}
$matrix1 = array(
    array(18, 23, 39),
    array(42, 54, 66),
    array(75, 88, 92)
);
$matrix2 = array(
    array(91, 82, 75),
    array(64, 55, 40),
    array(33, 22, 18)
);
$resultMatrix = addMatrices($matrix1, $matrix2);
echo "Matrix 1 :<br>";
displayMatrix($matrix1);
echo "<br>";
echo "Matrix 2 :<br>";
displayMatrix($matrix2);
echo "<br>";
echo "Sum of the matrices :<br>";
displayMatrix($resultMatrix);
?>
