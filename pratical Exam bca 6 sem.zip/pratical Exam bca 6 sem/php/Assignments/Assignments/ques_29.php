<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Students Enrolled in PHP Course</title>
<style>
  body 
  {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
  }
  h2 
  {
    text-align: center;
    color: #333;
  }
  table 
  {
    width: 100%;
    border-collapse: collapse;
    margin: 20px auto;
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
  }
  th, td 
  {
    padding: 10px;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }
  th 
  {
    background-color: #f2f2f2;
    font-weight: bold;
  }
  tr:hover 
  {
    background-color: #f9f9f9;
  }
</style>
</head>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "aryan123";
$dbname = "lab_db";

$conn = new mysqli($servername, $username, $password, $dbname,3307);

if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Student WHERE course = 'PHP'";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
    echo "<h2>Students enrolled in PHP course:</h2>";
    echo "<table><tr><th>ID</th><th>Name</th><th>Course</th><th>Age</th></tr>";
    while($row = $result->fetch_assoc()) 
    {
        echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["course"]."</td><td>".$row["age"]."</td></tr>";
    }
    echo "</table>";
} 
else 
{
    echo "<h2>No results found.</h2>";
}
$conn->close();
?>
</body>
</html>
