<?php
require 'require_example.php';
// This line will not be executed if "require_example.php" is not found
echo "<br>This is a lab file of PHP created by Aryan Amar";
?>
