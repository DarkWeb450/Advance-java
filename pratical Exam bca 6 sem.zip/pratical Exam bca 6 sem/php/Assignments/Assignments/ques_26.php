<!DOCTYPE html>
<html>
<head>
    <title>Calculator</title>
    <style>
        body 
        {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .calculator 
        {
            width: 300px;
            margin: 0 auto;
            background-color: #fff; 
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        input[type="text"] 
        {
            width: 100%;
            margin-bottom: 10px;
            padding: 10px;
            font-size: 18px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="button"] 
        {
            width: 50px;
            height: 50px;
            margin: 5px;
            font-size: 18px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="button"]:hover 
        {
            background-color: #ddd;
        }
        input[type="button"].equals 
        {
            background-color: #4CAF50;
            color: white;
        }
    </style>
</head>
<body>

<div class="calculator">
    <h2>Calculator</h2>
    <p>Created by Aryan Amar</p> 
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <input type="text" name="display" id="display" value="<?php echo isset($_POST['display']) ? $_POST['display'] : ''; ?>" readonly><br>
        <input type="button" value="1" onclick="addToDisplay('1')">
        <input type="button" value="2" onclick="addToDisplay('2')">
        <input type="button" value="3" onclick="addToDisplay('3')">
        <input type="button" value="+" onclick="addToDisplay('+')"><br>
        <input type="button" value="4" onclick="addToDisplay('4')">
        <input type="button" value="5" onclick="addToDisplay('5')">
        <input type="button" value="6" onclick="addToDisplay('6')">
        <input type="button" value="-" onclick="addToDisplay('-')"><br>
        <input type="button" value="7" onclick="addToDisplay('7')">
        <input type="button" value="8" onclick="addToDisplay('8')">
        <input type="button" value="9" onclick="addToDisplay('9')">
        <input type="button" value="*" onclick="addToDisplay('*')"><br>
        <input type="button" value="0" onclick="addToDisplay('0')">
        <input type="button" value="." onclick="addToDisplay('.')">
        <input type="reset" value="C">
        <input type="button" class="equals" value="=" onclick="calculate()">
        <input type="button" value="/" onclick="addToDisplay('/')">
    </form>
</div>

<script>
    function addToDisplay(value) 
    {
        document.getElementById('display').value += value;
    }

    function calculate() 
    {
        var display = document.getElementById('display').value;
        var result = eval(display);
        document.getElementById('display').value = result;
    }
</script>

</body>
</html>
