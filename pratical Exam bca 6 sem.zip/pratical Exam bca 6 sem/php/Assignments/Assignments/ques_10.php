<?php
function multiplyMatrices($matrix1, $matrix2) 
{
    $rows1 = count($matrix1);
    $cols1 = count($matrix1[0]);
    $cols2 = count($matrix2[0]);
    $result = array();
    for ($i = 0; $i < $rows1; $i++) 
    {
      for ($j = 0; $j < $cols2; $j++) 
      {
        $result[$i][$j] = 0;
        for ($k = 0; $k < $cols1; $k++) 
        {
         $result[$i][$j] += $matrix1[$i][$k] * $matrix2[$k][$j];
        }
      }
    }
    return $result;
}
function displayMatrix($matrix) 
{
 foreach ($matrix as $row) 
 {
  foreach ($row as $cell) 
  {
   echo $cell . "\t";
  }
   echo "<br>";
 }
}
$matrix1 = array(
    array(12, 21, 33),
    array(44, 55, 60),
    array(71, 83, 94)
);
$matrix2 = array(
    array(95, 84, 78),
    array(63, 51, 43),
    array(30, 26, 11)
);
$resultMatrix = multiplyMatrices($matrix1, $matrix2);
echo "Matrix 1 :<br>";
displayMatrix($matrix1);
echo "<br>";
echo "Matrix 2 :<br>";
displayMatrix($matrix2);
echo "<br>";
echo "Product of the matrices :<br>";
displayMatrix($resultMatrix);
?>
