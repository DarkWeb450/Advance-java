<?php
function fibonacci($n)
{
    if ($n <= 1) 
    {
        return $n;
    } 
    else 
    {
        return (fibonacci($n - 1) + fibonacci($n - 2));
    }
}
echo "First 20 Fibonacci numbers are as follows :<br>";
for ($i = 0; $i < 20; $i++) 
{
    echo fibonacci($i) . "<br>";
}
?>
