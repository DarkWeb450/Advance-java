<!DOCTYPE html>
<html>
<head>
    <title>Form Handling with the help of POST Method</title>
</head>
<body>
<h2>Enter Your Details:</h2>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="name">Name :</label><br>
    <input type="text" id="name" name="name"><br><br>
    <label for="email">Email :</label><br>
    <input type="text" id="email" name="email"><br><br>
    <label for="gender">Gender :</label><br>
    <input type="radio" id="male" name="gender" value="male">
    <label for="male">Male</label>
    <input type="radio" id="female" name="gender" value="female">
    <label for="female">Female</label>
    <input type="radio" id="other" name="gender" value="other">
    <label for="other">Other</label><br><br>
    <label for="interests">Hobbies :</label><br>
    <input type="checkbox" id="running" name="interests[]" value="running">
    <label for="music">Running</label>
    <input type="checkbox" id="satsang" name="interests[]" value="satsang">
    <label for="sports">Satsang</label>
    <input type="checkbox" id="bhajan" name="interests[]" value="bhajan">
    <label for="reading">Bhajan</label><br><br>
    <input type="submit" value="Submit">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
if (isset($_POST["name"]) && isset($_POST["email"]) && isset($_POST["gender"])) 
{
 $name = $_POST["name"];
 $email = $_POST["email"];
 $gender = $_POST["gender"];
 echo "<h2>Submitted Details :</h2>";
 echo "Name: $name<br>";
 echo "Email: $email<br>";
 echo "Gender: $gender<br>";
 if(isset($_POST["interests"])) 
 {
  $interests = $_POST["interests"];
  echo "Interests: " . implode(", ", $interests);
 } 
 else 
 {
  echo "Interests: None selected";
 }
}
}
?>
</body>
</html>
