<?php
function divide($numerator, $denominator) 
{
 if ($denominator == 0) 
 {
  throw new Exception("We cannot divide anything by zero.");
 }
 return $numerator / $denominator;
}

try 
{
 $result = divide(10, 0); 
 echo "Result : $result";
} 
catch (Exception $e) 
{
 echo "Exception caught : " . $e->getMessage();
}
?>
