<?php 
function Fibonacci_series($number){ 
if ($number == 0) 
return 0;	 
else if ($number == 1) 
return 1;	 
else
return (Fibonacci_series($number-1) + Fibonacci_series($number-2)); 
} 
$number = 20;
echo "The first 20 fibonacci numbers are as follows :<br>";
 for ($counter = 0; $counter < $number; $counter++)
{ 
 echo Fibonacci_series($counter) . "<br>"; 
} 
?> 
