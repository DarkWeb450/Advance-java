<?php
$filename = "example3.txt";
$file = fopen($filename, "w");
if ($file) 
{
 $initialContent = "My name is Aryan Amar.<br>";
 fwrite($file, $initialContent);
 fclose($file);
 echo "Initial content has been written successfully.<br>";
} 
else 
{
 echo "Error: Unable to open file for writing.<br>";
}
$file = fopen($filename, "a");
if ($file) 
{
 $additionalContent = "My enrollment number is A45304821047.";
 fwrite($file, $additionalContent);
 fclose($file);
 echo "Additional content has been written successfully.<br><br>";
} 
else 
{
 echo "Error: Unable to open file for appending.<br>";
}
$updatedContent = file_get_contents($filename);
echo "Updated content of the file :<br>";
echo nl2br($updatedContent); 
?>
