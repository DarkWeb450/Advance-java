<!DOCTYPE html>
<html>
<head>
    <title>File Upload</title>
</head>
<body>
    <h2>File Upload</h2>
    <form method="post" enctype="multipart/form-data">
        Select file to upload :
        <input type="file" name="fileToUpload" id="fileToUpload"><br><br>
        <input type="submit" value="Upload File" name="submit">
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES["fileToUpload"])) 
    {
     $targetDirectory = "uploads/"; 
     $targetFile = $targetDirectory . basename($_FILES["fileToUpload"]["name"]);
     $uploadOk = 1;
     $fileType = strtolower(pathinfo($targetFile,PATHINFO_EXTENSION));
     if (file_exists($targetFile)) 
     {
     echo "<br>Sorry, file already exists.";
     $uploadOk = 0;
     }
     if ($_FILES["fileToUpload"]["size"] > 5000000) 
     { 
       echo "<br>Sorry, your file is too large.";
       $uploadOk = 0;
     }

     $allowedFormats = array("jpg", "jpeg", "png", "gif", "pdf");
     if (!in_array($fileType, $allowedFormats)) 
     {
       echo "<br>Sorry, only JPG, JPEG, PNG, GIF, and PDF files are allowed.";
       $uploadOk = 0;
     }
     if ($uploadOk == 0) 
     {
      echo "<br>Sorry, your file was not uploaded.";
     } 
     else 
     { 
     if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $targetFile)) 
     {
      echo "<br>The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
     } 
     else 
     {
      echo "<br>Sorry, there was an error uploading your file.";
     }
    }
    }
    ?>
</body>
</html>
