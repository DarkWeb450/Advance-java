<?php
// example.php

echo "Greetings!!!!! My name is Aryan Amar. Presently, I am pursuing BCA from Amity University, Patna.<br>";
?>
