<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Employee Table and Insert Records</title>
    <style>
        body 
        {
            font-family: Arial, sans-serif;
        }
        form 
        {
            max-width: 400px;
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        input[type="text"], input[type="number"] 
        {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        input[type="submit"] 
        {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover 
        {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <h2>Employee List</h2>
    <label for="name">Name :</label><br>
    <input type="text" id="name" name="name" required><br>
    <label for="designation">Designation :</label><br>
    <input type="text" id="designation" name="designation" required><br>
    <label for="salary">Salary :</label><br>
    <input type="number" id="salary" name="salary" required><br>
    <input type="submit" name="submit" value="Submit">
</form>

<?php
// Variable to track whether the table creation message has been shown
$tableCreationMessageShown = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) 
{
    // Database connection parameters
    $servername = "localhost";
    $username = "root";
    $password = "aryan123";
    $database = "lab_db";

    $conn = new mysqli($servername, $username, $password, $database,3307);

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql_create_table = "CREATE TABLE IF NOT EXISTS Employee (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        designation VARCHAR(100) NOT NULL,
        salary DECIMAL(10, 2) NOT NULL
    )";

    if ($conn->query($sql_create_table) === TRUE) 
    {
        if (!$tableCreationMessageShown) 
        {
            echo "<p>Employee table created successfully</p>";
            $tableCreationMessageShown = true;
        }
        
        $name = $_POST['name'];
        $designation = $_POST['designation'];
        $salary = $_POST['salary'];
        $sql_insert_record = "INSERT INTO Employee (name, designation, salary)
                              VALUES ('$name', '$designation', '$salary')";
        if ($conn->query($sql_insert_record) === TRUE) 
        {
            echo "<p>Record inserted successfully</p>";
        } 
        else 
        {
            echo "Error inserting record: " . $conn->error;
        }
    } 
    else 
    {
        echo "Error creating table: " . $conn->error;
    }

    $conn->close();
}
?>

</body>
</html>
