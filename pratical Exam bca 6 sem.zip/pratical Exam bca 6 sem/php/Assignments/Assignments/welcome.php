<?php
session_start();
if (!isset($_SESSION["username"])) 
{
    header("Location: ques_31.php");
    exit;
}
$username = $_SESSION["username"];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
    <style>
        body 
        {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container 
        {
            text-align: center;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 300px;
        }
        h2 
        {
            color: #333;
        }
        p 
        {
            color: #555;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Welcome <?php echo $username; ?>!!!!!</h2>
        <p>This is the welcome page. You are logged in!</p>
    </div>
</body>
</html>
