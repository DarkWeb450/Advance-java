<?php
//Concatenation function
function concatenate($string1, $string2) 
{
  return $string1 . $string2;
}
//String length function
function stringLength($string) 
{
  return strlen($string);
}
//Uppercase function
function uppercase($string) 
{
  return strtoupper($string);
}
//Lowercase function
function lowercase($string) 
{
  return strtolower($string);
}
//Substring function
function substring($string, $start, $length) 
{
 return substr($string, $start, $length);
}
//String reverse function
function reverse($string) 
{
 return strrev($string);
}
//Replace function
function replace($string, $search, $replace) 
{
 return str_replace($search, $replace, $string);
}
//Compare functions
function compare($string1, $string2) 
{
 return strcmp($string1,$string2);
}
// Testing the functions
$string1 = "Aryan";
$string2 = "Amar";
echo "Concatenation: " . concatenate($string1, $string2) . "<br><br>";
echo "String Length: " . stringLength($string1) . "<br><br>";
echo "Uppercase: " . uppercase($string1) . "<br><br>";
echo "Lowercase: " . lowercase($string1) . "<br><br>";
echo "Substring: " . substring($string1, 1, 3) . "<br><br>";
echo "Reverse: " . reverse($string1) . "<br><br>";
echo "Replace: " . replace($string1, "Hello", "Hi") . "<br><br>";
echo "Compare: " . compare($string1,$string2) . "<br><br>";
?>
