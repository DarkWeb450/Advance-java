<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Student</title>
<style>
  body 
  {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
  }
  .container 
  {
    max-width: 400px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0,0,0,0.1);
  }
  h2 
  {
    text-align: center;
    margin-bottom: 20px;
  }
  .form-group 
  {
    margin-bottom: 15px;
  }
  .form-group label 
  {
    display: block;
    font-weight: bold;
  }
  .form-group input 
  {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
  }
  .form-group input[type="submit"] 
  {
    background-color: #4caf50;
    color: #fff;
    cursor: pointer;
  }
  .form-group input[type="submit"]:hover 
  {
    background-color: #45a049;
  }
</style>
</head>
<body>
  <div class="container">
    <h2>Add New Student</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
      <div class="form-group">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
      </div>
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>
      </div>
      <div class="form-group">
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" required>
      </div>
      <div class="form-group">
        <input type="submit" value="Add Student" name="submit">
      </div>
    </form>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
    {
        // Database connection
        $servername = "localhost";
        $username = "root";
        $password = "aryan123";
        $dbname = "lab_db";
        $conn = new mysqli($servername, $username, $password, $dbname,3307);
        if ($conn->connect_error) 
        {
            die("Connection failed: " . $conn->connect_error);
        }
        $stmt = $conn->prepare("INSERT INTO Students (name, email, age) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $name, $email, $age);
        $name = $_POST["name"];
        $email = $_POST["email"];
        $age = $_POST["age"];
        $stmt->execute();
        echo "<p>New student added successfully!</p>";
        $stmt->close();
        $conn->close();
    }
    ?>
  </div>
</body>
</html>
