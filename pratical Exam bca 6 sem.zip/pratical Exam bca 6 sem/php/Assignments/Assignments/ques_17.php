<!DOCTYPE html>
<html>
<head>
    <title>Form Handling with the help of GET Method</title>
</head>
<body>
<h2>Please enter your details :</h2>
<form method="get" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="name">Name :</label><br>
    <input type="text" id="name" name="name"><br><br>
    
    <label for="email">Email :</label><br>
    <input type="text" id="email" name="email"><br><br>
    
    <input type="submit" value="Submit">
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") 
{
 if (isset($_GET["name"]) && isset($_GET["email"])) 
 {
  $name = $_GET["name"];
  $email = $_GET["email"];
  echo "<h2>Submitted Details :</h2>";
  echo "Name: $name<br>";
  echo "Email: $email<br>";
 }
}
?>
</body>
</html>
