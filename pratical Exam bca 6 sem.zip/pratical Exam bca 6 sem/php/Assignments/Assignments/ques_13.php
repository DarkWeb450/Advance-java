<?php

// Getting the current date and time
$currentDateTime = date("Y-m-d H:i:s");
// Displaying the current date and time
echo "Current Date and Time: $currentDateTime<br><br>";
// Getting the current date in different formats
$todayDate = date("Y-m-d");
$longDateFormat = date("l, F j, Y");
// Displaying the current date in different formats
echo "Today's Date (YYYY-MM-DD): $todayDate<br>";
echo "Today's Date (Long Format): $longDateFormat<br><br>";
// Gettting the current time in different formats
$currentTime = date("H:i:s");
$twelveHourFormat = date("h:i A");
// Displaying the current time in different formats
echo "Current Time (24-hour format): $currentTime<br>";
echo "Current Time (12-hour format): $twelveHourFormat<br><br>";
// Getting the day of the week, month, number of days in the month, year, and week number
$dayOfWeek = date("l");
$currentMonth = date("F");
$daysInMonth = date("t");
$currentYear = date("Y");
$currentWeekNumber = date("W");
// Displaying the retrieved information
echo "Day of the Week: $dayOfWeek<br>";
echo "Current Month: $currentMonth<br>";
echo "Number of Days in Current Month: $daysInMonth<br>";
echo "Current Year: $currentYear<br>";
echo "Current Week Number: $currentWeekNumber<br>";
?>
