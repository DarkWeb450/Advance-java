<?php

// Linear search function
function linearSearch($arr, $x) 
{
   $n = count($arr);
   for ($i = 0; $i < $n; $i++) 
   {
     if ($arr[$i] == $x) 
     {
      return $i; 
     }
   }
 return -1;
}

// Example array
$arr = array(10, 20, 30, 40, 50);

// Element to search
$searchElement = 30;

// Performing linear search
$result = linearSearch($arr, $searchElement);

// Displaying the result
if ($result != -1) 
{
 echo "Element $searchElement found at index $result.";
} 
else 
{
 echo "Element $searchElement not found.";
}

?>
