package Servlet;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.AttendanceDao;
import Entity.*;

@WebServlet("/")
public class AttendanceServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private AttendanceDao AttendanceDao;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/setAttendance":
				setAttendanceForUser(request, response);
				break;
//			case "/getAttendanceData":
//				getAllAttendanceOnGivenDate(request, response);
//				break;
			case "/getForAttendance":
				listForAttendance(request, response);
				break;
			case "/getSingleStudentAttendanceDetail":
				singleAttendanceDetail(request, response);
				break;	
			default:
				listStudent(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

	@Override
	public void init() throws ServletException {
		AttendanceDao = new AttendanceDao ();
	}

	private void listStudent(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Student> listStudent = AttendanceDao.getAllStudent();
		request.setAttribute("listStudent", listStudent);
		RequestDispatcher dispatcher = request.getRequestDispatcher("list-all.jsp");
		dispatcher.forward(request, response);
	}
	private void listForAttendance(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Student> listStudentForAttendance = AttendanceDao.getAllStudent();
		request.setAttribute("listStudentForAttendance", listStudentForAttendance);
		RequestDispatcher dispatcher = request.getRequestDispatcher("mark-attendance.jsp");
		dispatcher.forward(request, response);
	}
	
	
	private void singleAttendanceDetail(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		int id = Integer.parseInt(request.getParameter("id"));
		List<Attendance> listStudentForAttendance = AttendanceDao.getStudentWithAttendanceById(id);
		request.setAttribute("listStudentForAttendance", listStudentForAttendance);
		RequestDispatcher dispatcher = request.getRequestDispatcher("all-attendance-list.jsp");
		dispatcher.forward(request, response);

	}


	//here attendance work will happen
	private void setAttendanceForUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
	    List<Student> students = AttendanceDao.getAllStudent();
	    java.sql.Date today = new java.sql.Date(System.currentTimeMillis());
	    try {
	    	for (Student student : students) {
		        int studentId = student.getStudentId();
		        String attendanceValue = request.getParameter("attendance_" + studentId);
		        Attendance attendance = new Attendance(today+""+studentId,student, today, attendanceValue);
		        AttendanceDao.saveAttendance(attendance);
		    }
		} catch (Exception e) {
			System.out.print("haha error !!");
		}
	    // Redirect back to the homepage or wherever appropriate
	    response.sendRedirect("/attendance");
	}


	
	//show all user of current Date
//	private void getAllAttendanceOnGivenDate(HttpServletRequest request, HttpServletResponse response)
//			throws SQLException, ServletException, IOException {
////		int id = Integer.parseInt(request.getParameter("id"));
////		Student existingUser = AttendanceDao.getUser(id);
//		RequestDispatcher dispatcher = request.getRequestDispatcher("user-form.jsp");
////		request.setAttribute("user", existingUser);
//		dispatcher.forward(request, response);
//
//	}


}
