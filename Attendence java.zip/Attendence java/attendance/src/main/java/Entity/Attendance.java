package Entity;
import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "attendance")
public class Attendance {
    @Id
    @Column(name = "attendance_id")
    private String attendanceId;

    @ManyToOne
    @JoinColumn(name = "s_id")
    private Student student;

    @Column(name = "attendance_date")
    private Date  attendanceDate;

    @Column(name = "attendance")
    private String attendanceStatus;

	public Attendance(String attendanceId , Student student, Date  attendanceDate, String attendanceStatus) {
		super();
		this.attendanceId = attendanceId;
		this.student = student;
		this.attendanceDate = attendanceDate;
		this.attendanceStatus = attendanceStatus;
	}

	public String getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(String attendanceId) {
		this.attendanceId = attendanceId;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Date  getAttendanceDate() {
		return attendanceDate;
	}

	public void setAttendanceDate(Date  attendanceDate) {
		this.attendanceDate = attendanceDate;
	}

	public String getAttendanceStatus() {
		return attendanceStatus;
	}

	public void setAttendanceStatus(String attendanceStatus) {
		this.attendanceStatus = attendanceStatus;
	}

	public Attendance() {
		super();
		// TODO Auto-generated constructor stub
	}
	
    
}
