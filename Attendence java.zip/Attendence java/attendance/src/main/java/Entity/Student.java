package Entity;
import javax.persistence.*;
//import java.util.Date;

@Entity
@Table(name = "students")
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "s_id")
    protected int studentId;

    @Column(name = "name")
    protected String name;

    @Column(name = "enrollment", unique = true)
    protected String enrollment;
    
    @Column(name = "section", unique = true)
    protected String section;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String name, String enrollment, String section) {
		super();
		this.name = name;
		this.enrollment = enrollment;
		this.section = section;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEnrollment() {
		return enrollment;
	}

	public void setEnrollment(String enrollment) {
		this.enrollment = enrollment;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}
	
    
}
