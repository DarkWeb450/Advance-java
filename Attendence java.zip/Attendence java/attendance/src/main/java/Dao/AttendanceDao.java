package Dao;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;


import Entity.*;
import Utility.Hibernate_util;

public class AttendanceDao {
	public void saveAttendance(Attendance attendance) {
		Transaction transaction = null;
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// save the student object
			session.save(attendance);
			// commit transaction
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
	}


	@SuppressWarnings("unchecked")
	public List<Student> getAllStudent() {

		Transaction transaction = null;
		List<Student> listOfStudent = null;
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an user object

			listOfStudent = session.createQuery("from	 Student").getResultList();

			// commit transaction
			transaction.commit();
			session.close();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfStudent;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Attendance> getStudentWithAttendanceById(int studentId) {
		List<Attendance> listOfAttendance = null;
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			listOfAttendance = session.createQuery("from  Attendance WHERE s_id="+studentId).getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return listOfAttendance;
	}

	
	
	
}

