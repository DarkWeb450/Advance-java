package Entity;
import javax.persistence.*;


@Entity
@Table(name = "marks")
public class Marks {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "marks_id")
    private int marksId;

    @ManyToOne
    @JoinColumn(name = "s_id")
    private Student student;

    @Column(name = "viva")
    private int viva;
    
    @Column(name = "internal")
    private int internal;
    
    @Column(name = "midsem")
    private int midsem;
    
    @Column(name = "attendance")
    private int attendance;
    
    @Column(name = "practical")
    private int practical;

	public Marks() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Marks(Student student, int viva, int internal, int midsem, int attendance, int practical) {
		super();
		this.student = student;
		this.viva = viva;
		this.internal = internal;
		this.midsem = midsem;
		this.attendance = attendance;
		this.practical = practical;
	}

	public int getMarksId() {
		return marksId;
	}

	public void setMarksId(int marksId) {
		this.marksId = marksId;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public int getViva() {
		return viva;
	}

	public void setViva(int viva) {
		this.viva = viva;
	}

	public int getInternal() {
		return internal;
	}

	public void setInternal(int internal) {
		this.internal = internal;
	}

	public int getMidsem() {
		return midsem;
	}

	public void setMidsem(int midsem) {
		this.midsem = midsem;
	}

	public int getAttendance() {
		return attendance;
	}

	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}

	public int getPractical() {
		return practical;
	}

	public void setPractical(int practical) {
		this.practical = practical;
	}
	

	
}