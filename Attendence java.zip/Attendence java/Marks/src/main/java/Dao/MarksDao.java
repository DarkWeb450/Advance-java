package Dao;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;


import Entity.*;
import Utility.Hibernate_util;

public class MarksDao {
	public void saveMarks(Marks marks) {
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			session.save(marks);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@SuppressWarnings("unchecked")
	public List<Student> getAllStudent() {

		Transaction transaction = null;
		List<Student> listOfStudent = null;
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			// start a transaction
			transaction = session.beginTransaction();
			// get an user object

			listOfStudent = session.createQuery("from	 Student").getResultList();

			// commit transaction
			transaction.commit();
			session.close();
		} catch (Exception e) {
			if (transaction != null) {
				transaction.rollback();
			}
			e.printStackTrace();
		}
		return listOfStudent;
	}
	
	public Marks getStudentWithMarksById(int studentId) {
		Marks marks = null;
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			marks =  session.get(Marks.class, studentId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return marks;
	}



	public Student getStudent(int studentId) {
		Student student = null;
		try (Session session = Hibernate_util.getSessionFactory().openSession()) {
			student = session.get(Student.class, studentId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return student;
	}

	
	
	
}

