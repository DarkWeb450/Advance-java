package Servlet;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.MarksDao;
import Entity.*;

@WebServlet("/")
public class MarksServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MarksDao MarksDao;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/setMarks":
				insertMarks(request, response);
				break;
			case "/getMarksForm":
				getMarksFormData(request, response);
				break;
			case "/getSingleStudentMarks":
				singleStudentMarksDetail(request, response);
				break;	
			default:
				listStudent(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doGet(req, resp);
	}

	@Override
	public void init() throws ServletException {
		MarksDao = new MarksDao ();
	}

	//list of all user here
	private void listStudent(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Student> listStudent = MarksDao.getAllStudent();
		request.setAttribute("listStudent", listStudent);
		RequestDispatcher dispatcher = request.getRequestDispatcher("list-all.jsp");
		dispatcher.forward(request, response);
	}
	
	private void insertMarks(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Student student = MarksDao.getStudent(id);
		int viva = Integer.parseInt(request.getParameter("viva"));
		int internal = Integer.parseInt(request.getParameter("internal"));
		int midsem =Integer.parseInt(request.getParameter("midsem"));
		int attendance = Integer.parseInt(request.getParameter("attendance"));
		int practical = Integer.parseInt(request.getParameter("practical"));
		Marks marks = new Marks(student,viva,internal,midsem,attendance,practical);
		MarksDao.saveMarks(marks);
		response.sendRedirect("list");
	}
	
	
	private void singleStudentMarksDetail(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		int id = Integer.parseInt(request.getParameter("id"));
		Marks studentMarks= MarksDao.getStudentWithMarksById(id);
		request.setAttribute("marks", studentMarks);
		RequestDispatcher dispatcher = request.getRequestDispatcher("show-marks.jsp");
		dispatcher.forward(request, response);

	}

	
	//show all user of current Date
	private void getMarksFormData(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Student existingStudent = MarksDao.getStudent(id);
		RequestDispatcher dispatcher = request.getRequestDispatcher("upload-marks.jsp");
		request.setAttribute("user", existingStudent);
		dispatcher.forward(request, response);

	}


}
